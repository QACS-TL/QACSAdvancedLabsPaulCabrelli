﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Events.Common
{
    public static class EventBusConstants
    {
        public const string DeletePropertyQueue = "property-deleted-event";
    }
}
