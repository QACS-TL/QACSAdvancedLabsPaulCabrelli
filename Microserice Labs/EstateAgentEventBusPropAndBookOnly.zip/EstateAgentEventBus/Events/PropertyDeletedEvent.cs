﻿namespace Events
{
    public class PropertyDeletedEvent
    {
        public int PropertyId { get; set; }
    }
}
